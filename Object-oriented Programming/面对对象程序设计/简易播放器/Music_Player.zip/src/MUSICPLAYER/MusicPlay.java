package MUSICPLAYER;

public class MusicPlay {
    public MusicPlay() {
    }

    public static void main(String[] args) {
        new audioplay();
        new MyExtendsJFrame();
    }
}
