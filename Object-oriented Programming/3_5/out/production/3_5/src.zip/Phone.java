abstract class Phone implements PayAble {
    protected String code;

    public Phone(String code) {
        this.code = code;
    }
}
