import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int time = scanner.nextInt();
        double price = scanner.nextDouble();
        MobilePhone mobile = new MobilePhone("123456", time, price);
        System.out.println("Fee=" + mobile.pay());
        scanner.close();
    }
}
