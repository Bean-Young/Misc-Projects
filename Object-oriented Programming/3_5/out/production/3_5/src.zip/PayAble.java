public interface PayAble{
	public double pay();
}
